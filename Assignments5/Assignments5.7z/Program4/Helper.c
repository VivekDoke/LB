#include "Header.h"

////////////////////////////////////////////////////
//
// Name: Multiply
// Description: WAP which accept three numbers and 
// 				print its multiplication
// Input: int, int, int
// Output: int
// Author: Vivek Shrihari Doke
// Date: 03 August 2020
//
////////////////////////////////////////////////////

int Multiply(int iValue1, int iValue2, int iValue3) {
	int iMul = 0;
	iMul = iValue1 * iValue2 * iValue3;
	return iMul;
}
