#include "Header.h"

////////////////////////////////////////////////////////
//
// Name: ChkEqual 
// Description: WAP which accept two numbers and check
//				whether numbers are equal or not.
// Input: int
// Output: bool
// Author: Vivek Shrihari Doke 
// Date: 03 August 2020
//
////////////////////////////////////////////////////

BOOL ChkEqual(int iValue1, int iValue2) {
	if(iValue1 == iValue2) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}
